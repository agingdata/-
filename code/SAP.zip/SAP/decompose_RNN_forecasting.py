#encoding=utf-8

import numpy as np
import util
from models import decompose
import eval
from naive_RNN_forecasting import RNN_forecasting
from naive_MLP_forecasting import MLP_forecasting
from naive_SVR_forecasting import SVR_forecasting
from naive_RNN_forecasting import RNN_forecasting1
from naive_RNN_forecasting import RNN_forecasting2
import time
#import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
np.random.seed(15)


def decompose_RNN_forecasting(ts, dataset, freq, lag, epoch=20, hidden_num=64,
                              batch_size=32, lr=1e-3, unit="GRU", varFlag=False, maxLen=48, minLen=24, step=8):

    # decomposition
    trend, seasonal, residual = decompose.ts_decompose(ts, freq)
    print("trend shape:", trend.shape)
    print("peroid shape:", seasonal.shape)
    print("residual shape:", residual.shape)

    # Respectively predict decomposition
    resWin = trendWin = lag
    
    
 ########The following lines of code are used to implement different hybrid models   
 
 
  #  trTrain, trTest, MAE1, MRSE1, SMAPE1 = SVR_forecasting(trend, lookBack=lag, C=0.1, epsilon=0.01)
#    trTrain, trTest, MAE1, MRSE1, SMAPE1 = MLP_forecasting(trend, inputDim=lag, hiddenNum=hidden_dim, lr=lr, epoch=epoch, batchSize=batch_size, plot_flag=True)
    trTrain, trTest, MAE1, MRSE1, SMAPE1 = RNN_forecasting1(trend, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
                                            varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit1, lr=lr)
#    trTrain, trTest, MAE1, MRSE1, SMAPE1 = RNN_forecasting2(trend, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
#                                            varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit2, lr=lr)
#    trTrain, trTest, MAE1, MRSE1, SMAPE1 = RNN_forecasting(trend, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num, 
#                                                           varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit, lr=lr)
#                                                                                                
#    resTrain, resTest, MAE2, MRSE2, SMAPE2 = RNN_forecasting(residual, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
#                                            varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit, lr=lr)

                                            
#    resTrain, resTest, MAE2, MRSE2, SMAPE2 = SVR_forecasting(residual, lookBack=lag, C=0.1, epsilon=0.01)
#    resTrain, resTest, MAE2, MRSE2, SMAPE2 = SVR_forecasting(residual, lookBack=lag, C=0.1, epsilon=0.01)
#    resTrain, resTest, MAE2, MRSE2, SMAPE2 = MLP_forecasting(residual, inputDim=lag, hiddenNum=hidden_dim, lr=lr, epoch=epoch, batchSize=batch_size, plot_flag=True)
    resTrain, resTest, MAE2, MRSE2, SMAPE2 = RNN_forecasting1(residual, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
                                            varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit1, lr=lr)
#    resTrain, resTest, MAE2, MRSE2, SMAPE2 = RNN_forecasting2(residual, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
#                                            varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit2, lr=lr)


    print("trTrain shape:", trTrain.shape)
    print("resTrain shape:", resTrain.shape)
    print("trTest shape:", trTest.shape)
    print("resTest shape:", resTest.shape)


    # Data alignment
    trendPred, resPred = util.align(trTrain, trTest, trendWin, resTrain, resTest, resWin)
    print("trendPred shape is", trendPred.shape)
    print("resPred shape is", resPred.shape)

    # Get the final prediction result

    trainPred = trTrain+seasonal[trendWin:trendWin+trTrain.shape[0]]+resTrain
    testPred = trTest+seasonal[2*resWin+resTrain.shape[0]:]+resTest
  

    # Obtain ground-truth data
    
    data = dataset[freq//2:-(freq//2)]
    trainY = data[trendWin:trendWin+trTrain.shape[0]]
    testY = data[2*resWin+resTrain.shape[0]:]#length of data
    
    #Original sequence length of trend subsequence (with lag removed)
    trTrainY = trend[trendWin:trendWin+trTrain.shape[0]]
    trTestY = trend[2*trendWin+trTrain.shape[0]:]
    
    #Original sequence length of residual subsequence (with lag removed)
    resTrainY = residual[trendWin:trendWin+trTrain.shape[0]]
    resTestY = residual[2*trendWin+trTrain.shape[0]:]
    
      
 
    # evaluation
    MAE = eval.calcMAE(testY, testPred)
    print( MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)
    

    
#Visualization of trend subsequence prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
  #  plt.ylabel(" trend subsequence (Mb)",size=28) #y_axis lable
    plt.ylabel(" trend subsequence (x10 Mb)",size=28) #y_axis lable     
   # plt.plot([x for x in trTrainY],c='b', linewidth=3)
    plt.plot([x for x in trTrain],c='g', linewidth=3)
    gtruth = np.concatenate((trTrainY,  trTestY))
    plt.plot(gtruth,c='b', linewidth=1)
     #  plt.plot([None for _ in trTrainY]+[x for x in trTestY],c='b', linewidth=3)
    plt.plot([None for _ in trTrain]+[x for x in trTest],c='r', linewidth=3)
    plt.show()
    
#Visualization of residual subsequence prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
   # plt.ylabel("residual subsequence (Mb)",size=28) #y_axis lable 
    plt.ylabel("residual subsequence (x10 Mb)",size=28) #y_axis lable
   # plt.plot([x for x in resTrainY],c='b', linewidth=3)
    plt.plot([x for x in resTrain],c='g', linewidth=3)
    gtruth = np.concatenate((resTrainY,  resTestY))
    plt.plot(gtruth,c='b', linewidth=1)
  #  plt.plot([None for _ in resTrainY]+[x for x in resTestY],c='b', linewidth=3)
    plt.plot([None for _ in resTrain]+[x for x in resTest],c='r', linewidth=3)
    plt.show()
    
    
  #Visualization of final prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
 #   plt.ylabel("PSS of system_server (Mb)",size=28) #y_axis lable
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y_axis lable
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    gtruth = np.concatenate((trainY, testY))
    plt.plot(gtruth,c='b', linewidth=1)
 
    #plt.plot([None for _ in trainY]+[x for x in  testY],c='b', linewidth=3)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)
    plt.show()

    return trainPred, testPred, MAE, MRSE, SMAPE


if __name__ == "__main__":

    lag = 12  # if using varFlag, lag == maxLen
    batch_size = 16
    epoch = 100
    hidden_dim = 64
    unit = "GRU"
    unit1 = "RNN"
    unit2 = "LSTM"
    
    lr = 1e-4
    freq = 8
    varFlag = True
    minLen = 12  # only using TSD technology 
    #minLen = 6 # when using DVLGRU to predict,
    maxLen = 12
    step = 3


    ts, data = util.load_data("./data/freeMem1.csv", columnName="Mem")

    trainPred, testPred, mae, mrse, smape = decompose_RNN_forecasting(ts, data, lag=lag, freq=freq, unit=unit,
                                                                      varFlag=varFlag, minLen=minLen, maxLen=maxLen, 
                                                                      step=step, epoch=epoch, hidden_num=hidden_dim, lr=lr, batch_size=batch_size)




