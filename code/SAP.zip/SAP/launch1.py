# -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 13:14:58 2020

@author: lenovo
"""
import seaborn as sn

import pandas as pd
import matplotlib.pyplot as plt
# import data
#tips = sn.load_dataset("tips")  # csv file
d = pd.read_csv('./data/launch time.csv')


f, ax = plt.subplots(figsize = (12, 8))


sn.set(font_scale=2.5,style="whitegrid", color_codes=True)

sn.lmplot(x="Number of Samples", y="Launch Time (s)", data=d, size=7.5, aspect=1.5, line_kws={'color': 'red'})

plt.savefig("./data/lmplot1.png",dpi=1000)
plt.show()



