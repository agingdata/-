#encoding=utf-8

from models import RNNs
import util
import eval
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import csv
import numpy as np
np.random.seed(15)

def RNN_forecasting(dataset, lookBack, lr, inputDim=1, hiddenNum=64, outputDim=1, unit="GRU", epoch=20,
                    batchSize=30, varFlag=False, minLen=15, maxLen=30, step=5):

    # normalized data
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # Split the sequence into samples and organize them into the input form of RNN
    train, test = util.divideTrainTest(dataset)

    trainX = None
    trainY = None
    vtrainX = None
    vtrainY = None
    testX = None
    testY = None
    vtestX = None
    vtestY = None

    # build model and train
    RNNModel = RNNs.RNNsModel(inputDim, hiddenNum, outputDim, unit, lr)
    print ("model:", inputDim, outputDim)
    if varFlag:
        vtrainX, vtrainY = util.createVariableDataset(train, minLen, maxLen, step)
        vtestX, vtestY = util.createVariableDataset(test, minLen, maxLen, step)
        print("trainX shape is1", vtrainX.shape)
        print("trainY shape is", vtrainY.shape)
        print("testX shape is", vtestX.shape)
        print("testY shape is", vtestY.shape)
        RNNModel.train(vtrainX, vtrainY, epoch, batchSize)
    else:
        trainX, trainY = util.createSamples(train, lookBack)
        testX, testY = util.createSamples(test, lookBack)
        print("trainX shape is", trainX.shape)
        print("trainY shape is", trainY.shape)
        print("testX shape is", testX.shape)
        print("testY shape is", testY.shape)
        RNNModel.train(trainX, trainY, epoch, batchSize)

    # prediction
    if varFlag:
        trainPred = RNNModel.predictVarLen(vtrainX, minLen, maxLen, step)
        testPred = RNNModel.predictVarLen(vtestX, minLen, maxLen, step)
        trainPred= trainPred.reshape(-1, 1)
    else:
        trainPred = RNNModel.predict(trainX)
        testPred = RNNModel.predict(testX)
        trainPred = trainPred.reshape(-1, 1)

    if varFlag:
        # Convert the label of test
        testY = util.transform_groundTruth(vtestY, minLen, maxLen, step)
        testY = testY.reshape(-1, 1)
        testPred = testPred.reshape(-1, 1)
        print("testY", testY.shape)
        print("testPred", testPred.shape)

    # reverse
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = util.transform_groundTruth(vtrainY, minLen, maxLen, step)##Convert training set (if you use VL method when GRU training, you need to use this line)
    trainY = trainY.reshape(-1, 1)
    trainY = scaler.inverse_transform(trainY)
    

    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x-axis label
    #plt.ylabel("PSS of system_server (Mb)",size=28) #y-axis label
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y-axis label
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)


    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)

    return trainPred, testPred, MAE, MRSE, SMAPE

def RNN_forecasting1(dataset, lookBack, lr, inputDim=1, hiddenNum=64, outputDim=1, unit="RNN", epoch=20,
                    batchSize=30, varFlag=False, minLen=15, maxLen=30, step=5):

    # normalized data
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # Split the sequence into samples and organize them into the input form of RNN
    train, test = util.divideTrainTest(dataset)

    trainX = None
    trainY = None
    vtrainX = None
    vtrainY = None
    testX = None
    testY = None
    vtestX = None
    vtestY = None

    # build model and train
    RNNModel = RNNs.RNNsModel(inputDim, hiddenNum, outputDim, unit, lr)
    print ("model:", inputDim, outputDim)
    if varFlag:
        vtrainX, vtrainY = util.createVariableDataset(train, minLen, maxLen, step)
        vtestX, vtestY = util.createVariableDataset(test, minLen, maxLen, step)
        print("trainX shape is1", vtrainX.shape)
        print("trainY shape is", vtrainY.shape)
        print("testX shape is", vtestX.shape)
        print("testY shape is", vtestY.shape)
        RNNModel.train(vtrainX, vtrainY, epoch, batchSize)
    else:
        trainX, trainY = util.createSamples(train, lookBack)
        testX, testY = util.createSamples(test, lookBack)
        print("trainX shape is", trainX.shape)
        print("trainY shape is", trainY.shape)
        print("testX shape is", testX.shape)
        print("testY shape is", testY.shape)
        RNNModel.train(trainX, trainY, epoch, batchSize)

    # prediction
    if varFlag:
        trainPred = RNNModel.predictVarLen(vtrainX, minLen, maxLen, step)
        testPred = RNNModel.predictVarLen(vtestX, minLen, maxLen, step)
        trainPred= trainPred.reshape(-1, 1)
    else:
        trainPred = RNNModel.predict(trainX)
        testPred = RNNModel.predict(testX)
        trainPred = trainPred.reshape(-1, 1)

    if varFlag:
        # Convert the label of test
        testY = util.transform_groundTruth(vtestY, minLen, maxLen, step)
        testY = testY.reshape(-1, 1)
        testPred = testPred.reshape(-1, 1)
        print("testY", testY.shape)
        print("testPred", testPred.shape)

    # reverse
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = scaler.inverse_transform(trainY)
    

    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x-axis label
    #plt.ylabel("PSS of system_server (Mb)",size=28) #y-axis label
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y-axis label
    
    
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    #plt.vlines(191, 0, 95, colors = "k",linewidth=4,linestyles = "dashed")
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)


    # evaluation
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)

    return trainPred, testPred, MAE, MRSE, SMAPE

def RNN_forecasting2(dataset, lookBack, lr, inputDim=1, hiddenNum=64, outputDim=1, unit="LSTM", epoch=20,
                    batchSize=30, varFlag=False, minLen=15, maxLen=30, step=5):

    # Normalized data
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # Split the sequence into samples and organize them into the input form of RNN
    train, test = util.divideTrainTest(dataset)

    trainX = None
    trainY = None
    vtrainX = None
    vtrainY = None
    testX = None
    testY = None
    vtestX = None
    vtestY = None

    # Build model and train
    RNNModel = RNNs.RNNsModel(inputDim, hiddenNum, outputDim, unit, lr)
    print ("model:", inputDim, outputDim)
    if varFlag:
        vtrainX, vtrainY = util.createVariableDataset(train, minLen, maxLen, step)
        vtestX, vtestY = util.createVariableDataset(test, minLen, maxLen, step)
        print("trainX shape is1", vtrainX.shape)
        print("trainY shape is", vtrainY.shape)
        print("testX shape is", vtestX.shape)
        print("testY shape is", vtestY.shape)
        RNNModel.train(vtrainX, vtrainY, epoch, batchSize)
    else:
        trainX, trainY = util.createSamples(train, lookBack)
        testX, testY = util.createSamples(test, lookBack)
        print("trainX shape is", trainX.shape)
        print("trainY shape is", trainY.shape)
        print("testX shape is", testX.shape)
        print("testY shape is", testY.shape)
        RNNModel.train(trainX, trainY, epoch, batchSize)

    # prediction
    if varFlag:
        trainPred = RNNModel.predictVarLen(vtrainX, minLen, maxLen, step)
        testPred = RNNModel.predictVarLen(vtestX, minLen, maxLen, step)
        trainPred= trainPred.reshape(-1, 1)
    else:
        trainPred = RNNModel.predict(trainX)
        testPred = RNNModel.predict(testX)
        trainPred = trainPred.reshape(-1, 1)

    if varFlag:
        # Convert the label of test
        testY = util.transform_groundTruth(vtestY, minLen, maxLen, step)
        testY = testY.reshape(-1, 1)
        testPred = testPred.reshape(-1, 1)
        print("testY", testY.shape)
        print("testPred", testPred.shape)

    # reverse
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = scaler.inverse_transform(trainY)
    

    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x-axis label
   # plt.ylabel("PSS of system_server (Mb)",size=28) #y-axis label
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y-axis label
    
    
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    #plt.vlines(191, 0, 95, colors = "k",linewidth=4,linestyles = "dashed")
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)

    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)

    #util.plot(trainPred,trainY,testPred,testY)

    return trainPred, testPred, MAE, MRSE, SMAPE



if __name__ == "__main__":

    lag = 12
    batch_size = 16
    epoch = 100
    hidden_dim = 64
    lr = 1e-4
    unit1 = "RNN"
    unit2 = "LSTM"
    unit = "GRU"
    ts, data = util.load_data("./data/sys1.csv", columnName="Mem")
    
####choose different models according to requirement, including GRU, RNN, LSTM

#    trainPred, testPred, mae, mrse, smape = RNN_forecasting(data, lookBack=lag, epoch=epoch, batchSize=batch_size,
#                                            varFlag=False, minLen=12, maxLen=24, step=8, unit=unit, lr=lr)
#    trainPred, testPred, mae, mrse, smape = RNN_forecasting1(data, lookBack=lag, epoch=epoch, batchSize=batch_size, 
#                                                             varFlag=False, minLen=12, maxLen=24, step=8, unit=unit1, lr=lr)
    trainPred, testPred, mae, mrse, smape = RNN_forecasting2(data, lookBack=lag, epoch=epoch, batchSize=batch_size,
                                            varFlag= False, minLen=12, maxLen=24, step=8, unit=unit2, lr=lr)






