#encoding=utf-8

#
import numpy as np
import util
from models import decompose
import eval
from naive_RNN_forecasting import RNN_forecasting
import time
#import matplotlib.pyplot as plt
#matplotlib.use('qt5Agg')
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import naive_MLP_forecasting as ANNFORECAST
np.random.seed(15)


def decompose_MLP_forecasting(ts, dataset, freq, lag, epoch=20, hidden_num=64, batch_size=32, lr=1e-3):

    # decomposition
    trend, seasonal, residual = decompose.ts_decompose(ts, freq = freq)
    print("trend shape:", trend.shape)
    print("peroid shape:", seasonal.shape)
    print("residual shape:", residual.shape)

    #prediction respectively
    resWin = trendWin = lag
    t1 = time.time()
    trTrain, trTest, mae1, mrse1, smape1 = \
        ANNFORECAST.MLP_forecasting(trend, inputDim=trendWin, epoch=epoch, hiddenNum=hidden_num,
                                    batchSize=batch_size, lr=lr)
    resTrain, resTest, mae2, mrse2, smape2 = \
        ANNFORECAST.MLP_forecasting(residual, inputDim=trendWin, epoch=epoch, hiddenNum=hidden_num,
                                    batchSize=batch_size, lr=lr)
    t2 = time.time()
    print("time:", t2-t1)

    # Data align
    trendPred, resPred = util.align(trTrain, trTest, trendWin, resTrain, resTest, resWin)
    print("trendPred shape is", trendPred.shape)
    print("resPred shape is", resPred.shape)

    # obtain the final prediction results
  
    trainPred = trTrain + seasonal[trendWin:trendWin+trTrain.shape[0]] + resTrain
    testPred = trTest + seasonal[2 * resWin + resTrain.shape[0]:] + resTest
    

    # get ground_truth data
    data = dataset[freq // 2 : -(freq//2)]
    trainY = data[trendWin:trendWin+trTrain.shape[0]]
    testY = data[2 * resWin+resTrain.shape[0]:]
    
       #Original sequence length of trend subsequence (excluding lag)
    trTrainY = trend[trendWin:trendWin+trTrain.shape[0]]
    trTestY = trend[2*trendWin+trTrain.shape[0]:]
    
    #Original sequence length of residual subsequence (excluding lag)
    resTrainY = residual[trendWin:trendWin+trTrain.shape[0]]
    resTestY = residual[2*trendWin+trTrain.shape[0]:]

    # evaluation metrics
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print( MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print( SMAPE)

   
#Visualization of residual subsequence prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
    plt.ylabel(" trend subsequence (x10 Mb)",size=28) #y_axis lable
  #  plt.ylabel("trend subsequence (Mb)",size=28) #y_axis lable
   # plt.plot([x for x in trTrainY],c='b', linewidth=3)
    plt.plot([x for x in trTrain],c='g', linewidth=3)
    gtruth = np.concatenate((trTrainY,  trTestY))
    plt.plot(gtruth,c='b', linewidth=1)
     #  plt.plot([None for _ in trTrainY]+[x for x in trTestY],c='b', linewidth=3)
    plt.plot([None for _ in trTrain]+[x for x in trTest],c='r', linewidth=3)
    plt.show()
    
#Visualization of trend subsequence prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
    plt.ylabel("residual subsequence (x10 Mb)",size=28) #y_axis lable 
 #   plt.ylabel("residual subsequence (Mb)",size=28) #y_axis lable
    
   # plt.plot([x for x in resTrainY],c='b', linewidth=3)
    plt.plot([x for x in resTrain],c='g', linewidth=3)
    gtruth = np.concatenate((resTrainY,  resTestY))
    plt.plot(gtruth,c='b', linewidth=1)
     #  plt.plot([None for _ in resTrainY]+[x for x in resTestY],c='b', linewidth=3)
    plt.plot([None for _ in resTrain]+[x for x in resTest],c='r', linewidth=3)
    plt.show()
    
    
  #Visualization of final prediction results
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
  #  plt.margins(x=0)
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
 #   plt.ylabel("PSS of system_server (Mb)",size=28) #y_axis lable
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y_axis lable

    plt.plot([x for x in trainPred],c='g', linewidth=3)
    gtruth = np.concatenate((trainY, testY))
    plt.plot(gtruth,c='b', linewidth=1)
     #plt.plot([None for _ in trainY]+[x for x in  testY],c='b', linewidth=3)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)
    plt.show()



    return trainPred, testPred, MAE, MRSE, SMAPE


if __name__ == "__main__":

    lag = 12
    batch_size = 16
    epoch = 100
    hidden_dim = 64
    lr = 1e-4
    freq = 8

    ts, data = util.load_data("./data/freeMem5.csv", columnName="Mem")

    trainPred, testPred, mae, mrse, smape = decompose_MLP_forecasting(ts, data, lag=lag, freq=freq,
                                                                      epoch=epoch, hidden_num=hidden_dim,
                                                                      lr=lr, batch_size=batch_size)
