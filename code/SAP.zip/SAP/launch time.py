# -*- coding: utf-8 -*-
"""
Created on Wed Sep 16 11:38:52 2020

@author: lenovo
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


d = pd.read_csv('./data/launch time.csv')
fig1 = plt.figure(num=1,figsize=(12, 8))  # Create an image object
plt.plot(d["Launch Time (s)"],linewidth=3,color='b', markerfacecolor='blue',markersize=12)


plt.xlabel("Number of Samples", size=28) #x_axis lable
plt.ylabel("Launch Time (s)",size=28) #y_axis lable


plt.vlines(47, 0, 40, colors = "r",linewidth=3,linestyles = "dashed")
plt.vlines(54, 0, 40, colors = "g",linewidth=3,linestyles = "dashed")



   