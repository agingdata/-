# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
from models import MLP
import util
import eval
from sklearn.preprocessing import MinMaxScaler
import time
import numpy as np
import pandas as pd
np.random.seed(15)


def MLP_forecasting(dataset, inputDim, lr=1e-3, hiddenNum=50, outputDim=1, epoch=20, batchSize=30, plot_flag=False):


    scaler = MinMaxScaler(feature_range=(0.0, 1.0)).fit(dataset)
    dataset = scaler.transform(dataset)

    # divide the series into training/testing samples
    # NOTE: Not RNN format
    train, test = util.divideTrainTest(dataset)

    trainX, trainY = util.createSamples(train, inputDim, RNN=False)
    testX, testY = util.createSamples(test, inputDim, RNN=False)
    print("trainX shape is", trainX.shape)
    print("trainY shape is", trainY.shape)
    print("testX shape is", testX.shape)
    print("testY shape is", testY.shape)

    # buil model and train
    MLP_model = MLP.MLP_Model(inputDim, hiddenNum, outputDim, lr)
    t1 = time.time()
    MLP_model.train(trainX, trainY, epoch, batchSize)
    t2 = time.time()-t1
    print("train time is", t2)

    # forecasting
    trainPred = MLP_model.predict(trainX)
    testPred = MLP_model.predict(testX)

    # reverse the time series
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = scaler.inverse_transform(trainY)
    
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    

    # evaluate
    MAE = eval.calcMAE(testY, testPred)
    print( MAE)
    RMSE = eval.calcRMSE(testY, testPred)
    print(RMSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)
    
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x_axis lable
    plt.ylabel("PSS of system_server (Mb)",size=28) #y_axis lable
    #plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y_axis lable
    
    
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)

    return trainPred, testPred, MAE, RMSE, SMAPE


if __name__ == "__main__":

    lag = 12
    batch_size = 16
    epoch = 100
    hidden_dim = 64
    lr = 1e-4


    ts, data = util.load_data("./data/freeMem5.csv", columnName="Mem")
    trainPred, testPred, mae, mrse, smape = MLP_forecasting(data, inputDim=lag, hiddenNum=hidden_dim,
                                            lr=lr, epoch=epoch, batchSize=batch_size, plot_flag=True)

