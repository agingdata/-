from models import SVR

import util
import eval
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
np.random.seed(15)


def SVR_forecasting(dataset, lookBack, C=2.0, epsilon=0.01, plot_flag=False):

    # normalize time series
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # divide the series into training/testing samples
    # NOTE: Not RNN format
    train,test = util.divideTrainTest(dataset)

    trainX, trainY = util.createSamples(train, lookBack, RNN=False)
    testX, testY = util.createSamples(test, lookBack, RNN=False)
    print("trainX shape is", trainX.shape)
    print("trainY shape is", trainY.shape)
    print("testX shape is", testX.shape)
    print("testY shape is", testY.shape)

    # buil model and train
    SVRModel = SVR.SVRModel(C=C, epsilon=epsilon)
    SVRModel.train(trainX, trainY)

    # forecasting
    trainPred = SVRModel.predict(trainX).reshape(-1, 1)
    testPred = SVRModel.predict(testX).reshape(-1, 1)

    # reverse the time series
    trainPred = scaler.inverse_transform(trainPred)
    trainY = scaler.inverse_transform(trainY)
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)

    # evaluate
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    RMSE = eval.calcRMSE(testY, testPred)
    print(RMSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)
    
       
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x-axis label
    plt.ylabel("PSS of system_server (Mb)",size=28) #y-axis label
  #  plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #y-axis label
    
    
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
     # plt.vlines(191, 0, 95, colors = "k",linewidth=4,linestyles = "dashed")
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)
#   


    return trainPred,testPred, MAE, RMSE, SMAPE


if __name__ == "__main__":

    lag = 12
    C = 0.1
    epsilon = 0.01

    ts, data = util.load_data("./data/freeMem5.csv", columnName="Mem")
    trainPred, testPred, mae, mrse, smape = SVR_forecasting(data, lookBack=lag, C=C, epsilon=epsilon)

